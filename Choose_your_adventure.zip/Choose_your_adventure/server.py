from flask import Flask, render_template

app = Flask(__name__)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/adventure")
def Adventure():
    return render_template("adventure.html")

@app.route("/houses")
def Houses():
    return render_template("houses.html")

@app.route("/house1choice")
def House1():
    return render_template("house1choice.html")

@app.route("/house2choice")
def House2():
    return render_template("house2choice.html")

@app.route("/doors")
def Doors():
    return render_template("doors.html")

# @app.route()
# def Doors():
#     return render_template("door1.html")

# @app.route()
# def Doors():
#     return render_template("door2.html")

# @app.route()
# def Doors():
#     return render_template("door3.html")

@app.route("/gameover")
def Gameover():
    return render_template("gameover.html")

app.run(debug=True, host="0.0.0.0")
